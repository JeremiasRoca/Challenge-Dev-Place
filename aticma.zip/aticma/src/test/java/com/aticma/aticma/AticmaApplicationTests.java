package com.aticma.aticma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AticmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
