package com.aticma.aticma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AticmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AticmaApplication.class, args);
	}

}
